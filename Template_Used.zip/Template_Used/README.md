This is the template files for a django social media project

Link to the full application source code: https://github.com/tomitokko/django-social-media-website
